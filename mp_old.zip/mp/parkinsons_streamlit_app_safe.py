# parkinsons_streamlit_app_safe.py
import os
import streamlit as st
import sounddevice as sd
from scipy.io.wavfile import write
import numpy as np
import pandas as pd
import joblib
# NOTE: 'parselmouth' is the correct module name to import, even if installed via 'praat-parselmouth'
import parselmouth 
from parselmouth.praat import call
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from imblearn.over_sampling import SMOTE

# -------------------------
# Config
# -------------------------
# NOTE: You MUST have a file named 'pd_voice_data.csv' in the same directory
DATA_FILE = 'pd_voice_data.csv'
MODEL_FILE = 'best_gb_parkinsons_model.pkl'
SCALER_FILE = 'data_scaler.pkl'
LIVE_WAV_FILE = 'live_voice_sample.wav'
SAMPLE_RATE = 44100
RECORD_DURATION = 5  # seconds
# List of 22 features required by the original dataset
FEATURE_NAMES = [
    'MDVP:Fo(Hz)', 'MDVP:Fhi(Hz)', 'MDVP:Flo(Hz)', 'MDVP:Jitter(%)', 
    'MDVP:Jitter(Abs)', 'MDVP:RAP', 'MDVP:PPQ', 'Jitter:DDP', 'MDVP:Shimmer', 
    'MDVP:Shimmer(dB)', 'Shimmer:APQ3', 'Shimmer:APQ5', 'MDVP:APQ', 
    'Shimmer:DDA', 'NHR', 'HNR', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE'
]

# -------------------------
# Safe feature extraction (Updated logic for robustness)
# -------------------------
def extract_acoustic_features(audio_file_path):
    """
    Extracts 22 acoustic features from a given WAV file using Parselmouth/Praat.
    Returns: numpy array of features for model, and a dictionary of features for display.
    """
    try:
        sound = parselmouth.Sound(audio_file_path)
        # Use tighter pitch settings for potentially dysphonia-affected speech
        pitch = call(sound, "To Pitch", 0.0, 50, 600)
        point_process = call(sound, "To PointProcess (periodic, cc)", 50, 600)

        def safe_call(obj, command, *args):
            try:
                return call(obj, command, *args)
            except:
                return 0.0

        # --- Dynamic Feature Extraction ---
        features_dict = {
            'MDVP:Fo(Hz)': safe_call(pitch, "Get mean", 0, 0, "Hertz"),
            'MDVP:Fhi(Hz)': safe_call(pitch, "Get maximum", 0, 0, "Hertz", "Parabolic"),
            'MDVP:Flo(Hz)': safe_call(pitch, "Get minimum", 0, 0, "Hertz", "Parabolic"),
            'MDVP:Jitter(%)': safe_call(point_process, "Get jitter (local)", 0, 0, 0.0001, 0.02, 1.3),
            'MDVP:Jitter(Abs)': safe_call(point_process, "Get jitter (local, absolute)", 0, 0, 0.0001, 0.02, 1.3) * 1000,
            'MDVP:RAP': safe_call(point_process, "Get jitter (rap)", 0, 0, 0.0001, 0.02, 1.3),
            'MDVP:PPQ': safe_call(point_process, "Get jitter (ppq5)", 0, 0, 0.0001, 0.02, 1.3),
            'Jitter:DDP': safe_call(point_process, "Get jitter (ddp)", 0, 0, 0.0001, 0.02, 1.3),
            'MDVP:Shimmer': safe_call([sound, point_process], "Get shimmer (local)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'MDVP:Shimmer(dB)': safe_call([sound, point_process], "Get shimmer (local_dB)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'Shimmer:APQ3': safe_call([sound, point_process], "Get shimmer (apq3)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'Shimmer:APQ5': safe_call([sound, point_process], "Get shimmer (apq5)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'MDVP:APQ': safe_call([sound, point_process], "Get shimmer (apq11)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'Shimmer:DDA': safe_call([sound, point_process], "Get shimmer (dda)", 0, 0, 0.0001, 0.02, 1.3, 1.6),
            'NHR': safe_call(sound, "Get noise to harmonics ratio", 0, 0),
            'HNR': safe_call(sound, "Get harmonicity (cc)", 0.01, 50, 0.1, 1.0),
            # Fill the remaining 6 features with placeholders (0.0) as they are not standard Praat outputs
            'RPDE': 0.0, 'DFA': 0.0, 'spread1': 0.0,
            'spread2': 0.0, 'D2': 0.0, 'PPE': 0.0
        }
        
        # Ensure the feature array order explicitly matches the FEATURE_NAMES list for safety
        feature_values = [features_dict.get(name, 0.0) for name in FEATURE_NAMES]
        feature_array = np.array([feature_values], dtype=float).reshape(1, -1)
        
        return feature_array, features_dict
        
    except Exception as e:
        # Return a zero array of the correct size and an empty dict on failure
        st.error(f"Failed to extract features: {e}. Check if the audio file is valid.")
        return np.zeros((1, len(FEATURE_NAMES))), {}

# -------------------------
# Train + save model
# -------------------------
def train_and_save_model():
    if not os.path.exists(DATA_FILE):
        st.error(f"🚨 **Dataset Error:** The required file **'{DATA_FILE}'** was not found in the current directory.")
        st.error("Please place the voice data CSV file in the same folder as this script and try again.")
        return None, None

    data = pd.read_csv(DATA_FILE)
    if 'name' in data.columns:
        data = data.drop(columns=['name'])
    if 'status' not in data.columns:
        st.error("Dataset must have 'status' column to train the model.")
        return None, None

    # Check if features match the expected list (critical for consistent modeling)
    data_features = set(data.drop(columns=['status']).columns)
    required_features = set(FEATURE_NAMES)
    
    missing_features = required_features - data_features
    if missing_features:
        st.error(f"Dataset missing required features: {missing_features}")
        return None, None
        
    # Reorder features to match the expected FEATURE_NAMES list
    X = data[FEATURE_NAMES].copy()
    y = data['status']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Use SMOTE to handle class imbalance
    sm = SMOTE(random_state=42)
    X_train_res, y_train_res = sm.fit_resample(X_train_scaled, y_train)

    gb = GradientBoostingClassifier(random_state=42)
    param_grid = {'n_estimators': [100, 200], 'learning_rate': [0.05, 0.1], 'max_depth': [3, 4]}
    grid = GridSearchCV(gb, param_grid, cv=5, scoring='accuracy', n_jobs=-1)
    with st.spinner("⏳ Training & hyperparameter tuning..."):
        grid.fit(X_train_res, y_train_res)

    best_model = grid.best_estimator_
    y_pred = best_model.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)

    # Save model and scaler
    joblib.dump(best_model, MODEL_FILE)
    joblib.dump(scaler, SCALER_FILE)

    st.success(f"✅ Model trained & saved! Test Accuracy: **{acc*100:.2f}%**")
    st.write("Best parameters:", grid.best_params_)

    # 📊 Show Confusion Matrix
    st.subheader("Confusion Matrix")
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Healthy', 'Parkinson'], yticklabels=['Healthy', 'Parkinson'], ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    st.pyplot(fig)

    # 📈 Show Precision, Recall, F1-score
    st.subheader("Classification Report")
    report = classification_report(y_test, y_pred, output_dict=True)
    st.dataframe(pd.DataFrame(report).T)

    return best_model, scaler

# -------------------------
# Predict
# -------------------------
def predict_from_audio(model, scaler, audio_path):
    features_array, features_dict = extract_acoustic_features(audio_path)
    
    if not features_dict or not features_array.any():
        return -1, 0.0, None

    scaled = scaler.transform(features_array)
    pred = model.predict(scaled)[0]
    prob = model.predict_proba(scaled)[0][pred]
    
    return int(pred), float(prob), features_dict

# -------------------------
# Streamlit UI
# -------------------------
st.set_page_config(page_title="Parkinson's Voice Analyzer", page_icon="🎙", layout="centered")
st.title("🎙 Parkinson's Voice Analyzer")
st.write("Record a sustained vowel (e.g., 'Aaaah') and analyze voice features.")

# Load model
model, scaler = None, None
if os.path.exists(MODEL_FILE) and os.path.exists(SCALER_FILE):
    try:
        model = joblib.load(MODEL_FILE)
        scaler = joblib.load(SCALER_FILE)
        st.info("Loaded existing model and scaler. Ready for analysis.")
    except Exception as e:
        st.warning(f"Could not load model/scaler: {e}. Please retrain.")
        model, scaler = None, None

col1, col2 = st.columns(2)
with col1:
    if st.button("🔁 Retrain Model"):
        model, scaler = train_and_save_model()

with col2:
    if st.button("🎤 Record Voice"):
        st.info(f"Recording for **{RECORD_DURATION} sec**... Please say a sustained 'Aaaah'")
        try:
            recording = sd.rec(int(RECORD_DURATION * SAMPLE_RATE), samplerate=SAMPLE_RATE, channels=1, dtype='int16')
            sd.wait()
            write(LIVE_WAV_FILE, SAMPLE_RATE, recording)
            st.success(f"Recording saved to **{LIVE_WAV_FILE}**")
        except Exception as e:
            st.error(f"Recording failed: {e}. Check your microphone setup/permissions.")

st.markdown("---")

if os.path.exists(LIVE_WAV_FILE):
    st.subheader("Last Recorded Sample")
    st.audio(LIVE_WAV_FILE)
    
    if st.button("🔬 Analyze Recording"):
        if model is None or scaler is None:
            st.warning("Model not loaded. Please Retrain the model first.")
        else:
            with st.spinner("Extracting features and predicting..."):
                pred, prob, features_dict = predict_from_audio(model, scaler, LIVE_WAV_FILE)
            
            if pred == -1:
                st.error("Analysis failed. Could not extract meaningful voice features.")
            else:
                # --- Display Prediction Result ---
                st.subheader("Analysis Result")
                if pred == 1:
                    st.error(f"⚠️ **Parkinson's Detected** — Confidence: **{prob*100:.2f}%**")
                else:
                    st.success(f"✅ **Healthy Voice** — Confidence: **{prob*100:.2f}%**")
                
                # --- Display Extracted Features ---
                st.subheader("Extracted Acoustic Features")
                
                # Create a DataFrame for nice formatting
                features_df = pd.DataFrame.from_dict(features_dict, orient='index', columns=['Value'])
                features_df['Value'] = features_df['Value'].apply(lambda x: f"{x:.4f}")
                
                st.dataframe(features_df, use_container_width=True)
                
                if st.button("💾 Save prediction log"):
                    try:
                        with open("prediction_log.txt", "a") as f:
                            f.write(f"Prediction: {'Parkinson' if pred==1 else 'Healthy'} | Confidence: {prob*100:.2f}%\n")
                            f.write(f"Features: {features_dict}\n")
                            f.write("-" * 30 + "\n")
                        st.success("Saved log to **prediction_log.txt**")
                    except Exception as e:
                        st.error(f"Could not save log file: {e}")

st.markdown("---")
st.markdown("### 💡 Running Instructions (VS Code)")
st.write("1. **Dependencies:** Run `pip install streamlit numpy pandas joblib scikit-learn matplotlib seaborn imblearn parselmouth sounddevice scipy`")
st.write("2. **Execute:** Run the app in your terminal using: `streamlit run parkinsons_streamlit_app_safe.py`")